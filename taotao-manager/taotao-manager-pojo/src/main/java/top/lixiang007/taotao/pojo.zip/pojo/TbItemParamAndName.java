package top.lixiang007.taotao.pojo;

public class TbItemParamAndName extends TbItemParam {

    private String itemCatName;

    public String getItemCatName() {
        return itemCatName;
    }

    public void setItemCatName(String itemCatName) {
        this.itemCatName = itemCatName;
    }
}
